# THIS PROJECT IS NO LONGER MAINTAINED !

if you want a working image host with discord embed support and can host node.js projects, check out
https://github.com/SomeBoringNerd/SomeBoringImageHost

# A PHP-based ShareX Compatible file storage system

## Features
- Based in PHP! Run it on your cPanel!
- Made by the one and only `memex#3981` on Discord
- forked by SomeBoringNerd for Discord embed support (and sharenix config)

## Install
1. edit $real_url, $json_url, $desc, and $site_name in upload.php
2. edit author_name and author_url in user.json
3. Upload `upload.php`, `upload.css` and `user.json` to your web server and chmod to `777`.
4. Create a folder named `img` and chmod to `777`.
5. Change the tokens to something random! (This is extremely important for security)!
6. Add example.sxcu to ShareX and configure to your server and token!
7. Profit.

## Changing/Adding tokens to server
1. Open upload.sxcu / sharenix.json
2. Find this line `$tokens = array("token1");`
3. Simply change token1 to a token of your choosing!
4. If you need more, simply add a comma and quotes.

## Adding token and server to ShareX/SXCU
1. Open `example.sxcu` with a text editor.
2. Change `YOUR_KEY_HERE` to to your key.
3. Change `http://yourdomain.com/upload.php` and `http://yourdomain.com/img/$json:url$` to your domain.

## Adding token and server to Sharenix
1. Open `sharenix.json` with a text editor.
2. Change `token` to to your key.
3. Change `http://url.domain/upload.php` to your domain (exemple : https://someboringnerd.xyz/upload.php).
4. replace your current sharenix.json by that one

## Support
Create an issue if my fork don't work. Ask me nicely for help with this and be patient.
Please don't spam the original author, they can't provide support for someone else's code.

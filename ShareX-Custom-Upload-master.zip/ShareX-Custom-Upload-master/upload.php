<?php
header('Content-type:application/json;charset=utf-8');
error_reporting(E_ERROR);
$tokens = array("token"); //Tokens go here
$sharexdir = "/var/www/html/img/"; //File directory
$lengthofstring = 5; //Length of file name

$real_url = "https://url.domain/img/";
$json_url = "https://url.domain/user.json";
$desc = "your description here";
$site_name = "your url here";

//Random file name generation
function RandomString($length) {
    $keys = array_merge(range(0,9), range('a', 'z'));

    for($i=0; $i < $length; $i++) {
        $key .= $keys[mt_rand(0, count($keys) - 1)];
    }
    return $key;
}

//Check for token
if(isset($_POST['secret']))
{
    //Checks if token is valid
    if(in_array($_POST['secret'], $tokens))
    {
        //Prepares for upload
        $filename = RandomString($lengthofstring);
        $target_file = $_FILES["sharex"]["name"];
        $fileType = pathinfo($target_file, PATHINFO_EXTENSION);

        //Accepts and moves to directory
        if (move_uploaded_file($_FILES["sharex"]["tmp_name"], $sharexdir.$filename.'.'.$fileType))
        {
            //Sends info to client
            $json = ['status' => 'OK','errormsg' => '','url' => $real_url . $filename . '.php'];
            // for discord embed, change to the root folder of your server if you know it
            $file = '/var/www/html/img/' . $filename . '.php';
            $embed_php = fopen($file, "w") or die("Unable to open file!");
            $txt = "
<html>
        <head>
                <meta name=\"twitter:card\" content=\"summary_large_image\">
                <meta property=\"og:title\" content=\"\" />
                <meta property=\"og:type\" content=\"website\" />
                <meta property=\"og:site_name\" content=\"". $site_name ."\" />
                <meta property=\"og:image\" content=\"". $real_url . $filename . '.' . $fileType ."\" />
                <meta property=\"og:description\" content=\"" . $desc ." \">
                <meta name=\"theme-color\" content=\"#0C2C63\">
                <link type=\"application/json+oembed\" href=\"" . $json_url . "\">
            <link rel=\"stylesheet\" href=\"/upload.css\">
        </head>
        <body>
            <center>
                <h1> here you go ! :-)</h1>
                <img src=\"" .$filename . '.' . $fileType . "\">
                <h3> Honestly, i don't think you should open weird links on discord, or anywhere on the internet for what matter</h3>
                <h4>made by <a href=\"https://github.com/SomeBoringNerd\">SomeBoringNerd</a></h4><br>
                <h4>forked from <a href=\"https://github.com/Inteliboi/ShareX-Custom-Upload\">Inteliboi</a></h4>
            </center>
        </body>
</html>";
            fwrite($embed_php, $txt);

        }
            else
        {
            //Warning
           $json = ['status' => 'ERROR','errormsg' => '','url' => 'File upload failed. Does the folder exist and did you CHMOD the folder?'];
        }
    }
    else
    {
        //Invalid key
        $json = ['status' => 'ERROR','errormsg' => '','url' => 'Invalid secret key.'];
    }
}
else
{
    //Warning if no uploaded data
    $json = ['status' => 'ERROR','errormsg' => '','url' => 'No POST data recieved.'];
}
//Sends json
echo($json);
?>

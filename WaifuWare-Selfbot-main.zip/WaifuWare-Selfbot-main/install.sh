npm run install

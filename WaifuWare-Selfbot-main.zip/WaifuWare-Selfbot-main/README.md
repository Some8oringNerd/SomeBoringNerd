# WaifuWare-Selfbot
Discord Selfbot made by TaxMachine with few fun utilities(no raid commands)

# Installation
Install <a href="https://nodejs.org">NodeJS</a> if its not already done<br>
Install <a href="https://git-scm.com/">Git</a> if its not already done
Clone this repository using git
```
git clone https://github.com/WaifuWare/WaifuWare-Selfbot
```

# Setup
<ul>
  <li>Put your token and your prefix in the config.json</li>
  <li>Run install.bat or install.sh (depending of your OS)</li>
  <li>Run the start.bat or start.sh (depending of your OS)</li>
  <li>Enjoy</li>
</ul>

# DISCLAIMER
**I AM NOT RESPONSIBLE OF ANY MALICIOUS USES, SELFBOTS ARE AGAINST DISCORD TOS AND YOU CAN GET YOUR ACCOUNT TERMINATED**

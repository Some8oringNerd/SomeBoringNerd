npm run start

# IDC-license

IDC License first iteration, 2022.

owned by SomeBoringNerd

The Owner allow the use of their work for personal / non-commercial work under the following guidelines / rules

That license describe what you can and can't do with my code and don't apply to end user, only people who want to use / edit the code of the repo.

> 1. DON'T STEAL THE CODE : 
Self explanatory, no one like people that clone the repo, change a few things (mostly erasing trace of the Owner) and / or claim the code as their own. You can use part of the code / the entirety of the repo if you want, just give credit where credit is due, and dont lie about who made what.

> 2. DON'T BE A BITCH : 
Less self explanatory, the code is distributed "as it is", without guarantee or promise that it will work on your machine / server / raspberry pi / smart fridge. I'm doing it for myself, not for you. If it don't work, just try to fix it. If you are extra cool, feel free to git commit your fix, I'd be happy to merge it.

> 3. BE COOL MAN : 
If for some reason, I allow you to make a buck out of my hard work, I rightfully expect you to pay me a beer or a coffee.

> 4. HAVE COMMON SENSE : 
I'm not a professional developper nor even a competent one, don't build your entire project around my work just in case it don't work (if it don't, please refer to the 2nd guideline). If you need it that bad, some money may help to fix it (gratitude don't pay my coffee addiction)

> 5. REMEMBER, I DO IT FOR FREE : 
I do not publish my code online so it can be used by multi-billion corporation for free and be expected to do the maintenance. If you need that library / project so badly for your business, hire me as freelancer instead of bitching out when my obviously not-safe code don't work out and you can't be bothered to fork it to fix it.

> 6. SPREAD THE LOVE : 
If that code was so useful to you, then yours might be to other people, the license I use is free and open like my code, even if some people can be a pain in your ass, remember that the community is here to support you. My code was here, you used it. It's only right to allow someone else to use yours.

based on the hilarious "don't be a dick" license by philsturgeon : 
http://dbad-license.org/

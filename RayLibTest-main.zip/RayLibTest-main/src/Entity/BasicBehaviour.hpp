#pragma once

class BasicBehaviour
{
    public:
        virtual void Update();
        
};
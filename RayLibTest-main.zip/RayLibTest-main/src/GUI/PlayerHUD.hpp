#pragma once

class PlayerHUD
{
    public:
        void Render()
        {

        }
};
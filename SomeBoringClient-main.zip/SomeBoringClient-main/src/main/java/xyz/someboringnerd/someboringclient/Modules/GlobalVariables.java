package xyz.someboringnerd.someboringclient.Modules;

public class GlobalVariables extends Module
{
    public static boolean VerboseMode = false;
    public static String PlayerScan = "";

    public GlobalVariables(String name, CATEGORY cat) {
        super(name, cat);
    }
}

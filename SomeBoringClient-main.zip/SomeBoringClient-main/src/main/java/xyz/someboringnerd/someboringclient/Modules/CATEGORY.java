package xyz.someboringnerd.someboringclient.Modules;

public enum CATEGORY {
    RENDER,
    CHAT,

    COMBAT,
    EXPLOIT,
    WORLD,
}

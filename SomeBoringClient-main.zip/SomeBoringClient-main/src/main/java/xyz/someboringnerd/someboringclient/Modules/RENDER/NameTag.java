package xyz.someboringnerd.someboringclient.Modules.RENDER;

public class NameTag {
}

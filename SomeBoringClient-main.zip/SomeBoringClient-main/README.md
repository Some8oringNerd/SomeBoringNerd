# SomeBoringClient
 private 1.12.2 "QOL" mod for anarchy server

# Build

in case the client leak or get released publicly (or both), here's the building instructions.

using java 8, run `./gradlew build`

# in game
type *help in chat to get a list of commands. The client dont have any kind of GUI.

# TODO :

>Keybind system

>pvp modules

>render modules

>movement modules

>exploit modules

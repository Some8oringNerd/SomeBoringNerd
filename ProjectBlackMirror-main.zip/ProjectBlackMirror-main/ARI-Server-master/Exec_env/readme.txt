Ce dossier sert a executer le logiciel serveur sur ma machine de test.

Vous retrouverai ici les images servant a tester le code ainsi qu'un fichier de config par défaut

notez que normalement il y'a aucune build du logiciel ici mais si y'en a une je déconseille de l'utiliser
#include "camerawidget.h"

CameraWidget::CameraWidget()
{

}

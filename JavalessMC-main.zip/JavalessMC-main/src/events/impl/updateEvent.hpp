#pragma once
#include "../eventmanager.hpp"

class UpdateEvent : public Event {};

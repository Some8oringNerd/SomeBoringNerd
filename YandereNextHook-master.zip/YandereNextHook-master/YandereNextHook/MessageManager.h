#pragma once
class MessageManager
{
public:
	static void DisplayMessage(const char* message);
	static void DisplayError(const char* message);
};


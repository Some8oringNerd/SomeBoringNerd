/*
    Save.rs
    Le module entier qui servira a sauvegarder la map, le joueur, et tout le reste
*/
# Player
Bien évidemment, ce projet est remplis d'erreurs de jeunesse ! Je vais donc essayer ici de définir la suite du projet, en ce qui concerne le monde.

L'objectif est d'avoir un joueur physique qui puisse avoir un inventaire, ainsi qu'une barre de vie.

```Rust
PlayerCoords {
    x,
    y,
    chunk
}
Inventory {
    TODO: A DEFINIR !
}
Player {
    hp: i32,
    coords: PlayerCoords,
    inventory: Inventory,
}

TODO: A SUIVRE

```
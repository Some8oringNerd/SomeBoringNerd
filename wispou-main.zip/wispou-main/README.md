> ⚠️ Suite à des différents avec les modérateurs du serveur d'Aywen, ce projet est à l'arrêt.


# 🔥 Wispou
**Concept:** An improved, rust-based recreation of a video game created by youtuber [Aywen](https://www.youtube.com/@aywenvideos).

# 🎮 Wispy
The original Java game is available [Here](https://github.com/Aywen1/wispy/).

## 📃 License
This project is under the [GPL-3.0 license](https://choosealicense.com/licenses/gpl-3.0/).

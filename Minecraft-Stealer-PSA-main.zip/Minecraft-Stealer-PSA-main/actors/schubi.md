# Schubi

Schubbi is an awfully good grabber, and the one I hate the most in fact. It works well, and is open source on github. Its particularity is that it use a middleman API to work, in order to hide the discord webhook.

Unlike most other branded rat, this one is not used by a specific group to my knowledge, but is provided for free.

Another thing is that you cant really DDOS or spam it, as the API contains a ratelimit, and multiple checks to make sure it is not being sent invalid accounts. If you are not rate-limited by the hoster before of course. Also, DDOSing is illegal.
### How to Neutralize

Unfortunatly, there is no easy way to neutralize this grabber. Your best way is to figure out who's hosting it and sending an abuse report. 

# AutoGG

AutoGG is probably one of the worse grabber out there (at least that I'm aware of). It grab your discord token and your session id. It is not obfuscated (usually).

**NOTE : I'M NOT TALKING ABOUT THE AUTOGG MOD, THIS GRABBER IS IMPERSONATING THE LEGITIMATE AUTOGG**
### How to Neutralize

## 1. Open in recaf
Just like any other grabber, open it in recaf (see the [ben](BenGrabber) page for a guide on that)

the malware is stored in the github.quantizr.autogg.guis.gui file in a really not subtle way

![a](../Images/autogg_url.png)

Use our [Skiddus Deletus](../Scripts/webhook_deleter) to quickly get rid of this grabber
# IDC-license
simple license that describe how you can and can't use the code of the person who use that license.

based on the hilarious "don't be a dick" license by philsturgeon

http://dbad-license.org/

cp /etc/nixos/* . -r

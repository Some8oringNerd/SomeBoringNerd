package xyz.someboringnerd.feurbot.modules.StashBot;

public class StashManager {
}

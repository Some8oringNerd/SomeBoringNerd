package xyz.someboringnerd.feurbot.modules.ChatBot;

public class ChatManager
{

}

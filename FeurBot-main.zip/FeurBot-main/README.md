# this project is no longer maintained. No support will be given for it no matter what or why. I don't work for the FeurGroup anymore and even if I did, the feurbots would not be used anyway as they were meant for 0B0T.org. Feel free to do anything you want with that code, no need to even credit me. 

# FeurBot

Is a multipurpose bot made for the FeurGroup on 0b0t.

# Compilation 

using Java 17, run `gradlew build`

# Huit Devs -> Un Jeu / Épisode 1
Un jeu développé par 8 volontaires qui n'ont pas pu se parler pendant le développement.
Thème : Créer un jeu ultra random !

## Participants :
- Elnoobo
- Valmontechno
- Someboringnerd
- ri1_
- RockingChair
- Guiireg
- Xernas
- Multycat

# Télécharger le jeu :
[Clique ici](https://github.com/AywenVideos/HuitDevs-UnJeu-Episode-1/releases/tag/1.0) Si Windows SmartScreen bloque l'exécution -> "informations complémentaires" et "Exécuter"

[Vidéo YouTube](https://www.youtube.com/watch?v=0l4rQi9RcJc&ab_channel=Aywen)
## License:
This project is licensed under the MIT License - see the LICENSE file for details.

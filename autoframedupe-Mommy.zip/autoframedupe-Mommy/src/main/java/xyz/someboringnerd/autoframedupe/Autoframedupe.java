package xyz.someboringnerd.autoframedupe;

import net.fabricmc.api.ModInitializer;

public class Autoframedupe implements ModInitializer
{
    @Override
    public void onInitialize()
    {
        new module();
    }
}

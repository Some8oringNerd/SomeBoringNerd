package xyz.someboringnerd.autoframedupe.client;

import net.fabricmc.api.ClientModInitializer;

public class AutoframedupeClient implements ClientModInitializer
{

    @Override
    public void onInitializeClient()
    {

    }
}

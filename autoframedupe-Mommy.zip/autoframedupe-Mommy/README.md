# autoframedupe

made for Mybios's server : 
play.cafouillage.com, 1.19.2

# download : 

https://github.com/SomeBoringNerd/autoframedupe/releases/tag/1.0

put in mod folder with Fabric API, compatible from 1.19.2 to 1.19.4
